<template>
  <div class="login">
    <h1>Login</h1>

    <form @submit.prevent="handleSubmit">
      <label for="username">Username</label>
      <input type="text" v-model="user.username" id="username" placeholder="Username" />

      <label for="password">Password</label>
      <input type="password" v-model="user.password" id="password" placeholder="Password" />

      <input type="submit" :value="isSending?'Connecting...':'Authenticate' " :disabled="isSending" />
    </form>
  </div>
</template>

<script>
// @ is an alias to /src
//import HelloWorld from '@/components/HelloWorld.vue'
import { JWT_TOKEN, USER_DATA_KEY } from "../config";

export default {
  name: "login",
  methods: {
    async handleSubmit() {
      this.isSending = true;
      try {
        const { data } = await this.$axios.post(`/auth/login`, this.user);

        localStorage.setItem(JWT_TOKEN, data.token);

        const { data: userData } = await this.$axios.get(`/user/user-data`);

        localStorage.setItem(USER_DATA_KEY, JSON.stringify(userData));
        this.isSending = false;
        this.$router.push("/");
      } catch (error) {
        this.isSending = false;
        console.error(JSON.stringify(error.message));
      }
    }
  },
  mounted() {
    this.isSending = false;
  },
  data() {
    return {
      isSending: false,
      user: {
        username: "secure.user@websitecompany.com",
        password: "ThePassword@987"
      }
    };
  }
};
</script>

<style lang="scss">
.login {
  width: 480px;
  margin: 0 auto;
  padding: 15px;
  background-color: #f0f1f1;
  border: 1px solid #dfdfdf;
  border-radius: 8px;
  margin-top: 10px;
}
input[type="text"],
input[type="password"] {
  background-color: #ffffff;
}
</style>