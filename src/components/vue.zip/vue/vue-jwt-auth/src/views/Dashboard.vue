<template>
  <div class="dashboard">
    <TopMenu />
    <img alt="Vue logo" src="../assets/logo.png" />
    <h1>Dashboard</h1>
    <div v-if="this.userData !== null">Name: {{userData.fullName}}</div>
    <button @click.prevent="logoutUser()">Logout</button>
  </div>
</template>

<script>
// @ is an alias to /src
import TopMenu from "@/components/TopMenu.vue";
import { USER_DATA_KEY } from "../config";

export default {
  name: "dashboard",
  components: {
    TopMenu
  },
  methods: {
    logoutUser() {
      this.$logoutUser();
    }
  },
  data() {
    return {
      userData: null
    };
  },
  mounted() {
    let userData = localStorage.getItem(USER_DATA_KEY);
    if (userData) {
      userData = JSON.parse(userData);
    }
    console.log("user data", userData);
    this.isSending = false;
  }
};
</script>
