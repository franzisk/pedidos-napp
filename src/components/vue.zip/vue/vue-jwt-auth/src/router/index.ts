import Vue from "vue";
import VueRouter from "vue-router";

import Login from "../views/Login.vue";
import Dashboard from "../views/Dashboard.vue";
import Public from "../views/Public.vue";

import { getToken } from "../main";

Vue.use(VueRouter);

const routes = [
    {
        path: "/",
        name: "dashboard",
        component: Dashboard
    },
    {
        path: "/dashboard",
        name: "dashboard",
        component: Dashboard
    },
    {
        path: "/public",
        name: "public",
        component: Public
    },
    {
        path: "/login",
        name: "login",
        component: Login
    }
];

const router = new VueRouter({ mode: "history", routes });

// Check before each page load whether the page requires authentication/
// if it does check whether the user is signed into the web app or
// redirect to the sign-in page to enable them to sign-in
router.beforeEach((to, from, next) => {
    const isLoginPage = to.name === "login";
    const isLoggedIn = getToken() !== undefined; //if ther a token then it's logged in
    const requiresAuth = to.matched.some(record => record.meta.requiresAuth);
    if (requiresAuth) {
        if (isLoggedIn) {
            if (isLoginPage) {
                next("/dashboard");
            } else {
                next();
            }
        } else {
            next("/login");
        }
    } else {
        if (isLoggedIn && isLoginPage) {
            next("/dashboard");
        } else {
            next();
        }
    }
});

export default router;
