<template>
  <div id="app">
    <!-- <nav>
      <router-link to="/">Home</router-link>
      <router-link :to="{name: 'about'}">About</router-link>
      <router-link to="/login">Login</router-link>
    </nav>-->
    <router-view />
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss">
#app {
  nav {
    background-color: #dbdbdb;
    a {
      display: inline-block;
      margin-right: 10px;
      text-decoration: none;
      color: #f7f4ee;
      padding: 10px;
      font-weight: 100;
      background-color: #1b1f24;
    }
  }
}
</style>