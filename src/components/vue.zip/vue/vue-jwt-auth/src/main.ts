import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import "./registerServiceWorker";
import axios from "axios";
import { JWT_TOKEN, USER_DATA_KEY, API_ROOT } from "./config";

import "vue-material/dist/vue-material.min.css";
import VueMaterial from "vue-material";
Vue.use(VueMaterial);

Vue.config.productionTip = false;

export const getToken = () => localStorage.getItem(JWT_TOKEN) || undefined;

export const api = axios.create({
    baseURL: API_ROOT
});
api.interceptors.request.use(config => {
    const _token = getToken();
    if (_token) {
        config.headers.authorization = `Bearer ${_token}`;
    }
    return config;
});
Vue.prototype.$axios = api;

Vue.prototype.$logoutUser = () => {
    localStorage.removeItem(JWT_TOKEN);
    localStorage.removeItem(USER_DATA_KEY);
    router.push("/login");
};

new Vue({
    router,
    store,
    render: h => h(App)
}).$mount("#app");
