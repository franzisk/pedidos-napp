export const JWT_TOKEN = "JWT_TOKEN_VUE";
export const USER_DATA_KEY = "USER_DATA_KEY_VUE";

// You should change this to your own server URL
export const API_ROOT = "https://shielded-mesa-51455.herokuapp.com";
