<template>
  <div class="login-form">
    <h1>Login</h1>
    <form @submit.prevent="handleSubmit">
      <label for="email">Email</label>
      <input type="text" v-model="usuario.email" id="email" placeholder="Seu email" />

      <label for="senha">Senha</label>
      <input type="password" v-model="usuario.senha" id="senha" placeholder="Sua senha" />

      <input type="submit" value="Enviar" />
    </form>
  </div>
</template>

<script>
import { CHAVE_USUARIO_LOGIN, JWT_TOKEN } from "./contants";

export default {
  name: "login-form",
  methods: {
    async handleSubmit() {
      const user = {
        username: this.usuario.email,
        password: this.usuario.senha
      };
      try {
        const url = "http://localhost:8088";
        const { data } = await this.$axios.post(`/auth/login`, user);
        localStorage.setItem(JWT_TOKEN, data.token);

        const { data: dadosUsuario } = await this.$axios.get(
          `/api/usuario/dados`
        );
        localStorage.setItem(CHAVE_USUARIO_LOGIN, JSON.stringify(dadosUsuario));

        this.$router.push("main/home");
      } catch (error) {
        console.error(JSON.stringify(error.message));
      }
    }
  },
  data() {
    return {
      usuario: {
        email: "usuario.comum@transportadora1.com.br",
        senha: "leonardo123"
      }
    };
  }
};
</script>

<style scoped>
.login-form {
  width: 480px;
  margin: 0 auto;
  padding: 15px;
  background-color: #f0f1f1;
  border: 1px solid #dfdfdf;
  border-radius: 8px;
  margin-top: 10px;
}
input[type="text"],
input[type="password"] {
  background-color: #ffffff;
}
</style>