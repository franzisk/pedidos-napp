<template>
  <div class="home">
    <div v-if="usuario!==null">
      <div>{{usuario.nome}}</div>
      <div>{{usuario.empresa.nome}}</div>
      <button @click.prevent="logout()">Logout</button>
      <md-button to="/main/transportadora/home">Transportadora</md-button>
      <div>{{msg }}</div>
    </div>
  </div>
</template>

<script>
import { CHAVE_USUARIO_LOGIN } from "./contants";

export default {
  name: "home",
  methods: {
    logout() {
      localStorage.setItem(CHAVE_USUARIO_LOGIN, null);
      this.$router.push("/login");
    }
  },
  data() {
    return {
      usuario: null,
      msg: ""
    };
  },
  mounted() {
    this.usuario = this.getUsuario();
    this.msg = "se você consegue ler isso parabéns você sabe ler texto invertido porém essa habilidade não tem utilidade"
      .split("")
      .reverse()
      .join("");
    console.log("msg = ", this.msg);
  }
};
</script>

<style scoped>
.home {
  margin-top: 90px;
}
</style>