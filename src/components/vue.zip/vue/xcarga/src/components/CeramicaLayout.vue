<template>
  <div class="grid">
    <div class="col col-2">
      <ul>
        <li>
          <router-link to="/main/home">Home</router-link>
        </li>
        <li>
          <router-link to="/main/about">Pedidos Sem Coleta</router-link>
        </li>
        <li>
          <router-link to="/main/contact">Transportadoras</router-link>
        </li>
        <li>
          <router-link to="/main/contact">Coletas Finalizadas</router-link>
        </li>
        <li>
          <router-link to="/main/contact">Coletas em Aberto</router-link>
        </li>
      </ul>
    </div>
    <div class="col col-10">
      <transition name="slide">
        <router-view></router-view>
      </transition>
    </div>
  </div>
</template>

<script>
export default {
  name: "ceramica-layout"
};
</script>

<style scoped>
</style>