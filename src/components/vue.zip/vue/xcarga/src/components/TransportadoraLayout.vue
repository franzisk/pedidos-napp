<template>
  <div class="transportadora-layout">
    <div class="md-layout">
      <div class="md-layout-item md-size-20">
        <div class="vertical-menu">
          <router-link to="/main/transportadora/home">Home</router-link>
          <router-link to="/main/transportadora/pedidos">Pedidos</router-link>
          <router-link to="/main/transportadora/coletas/finalizadas">Coletas Finalizadas</router-link>
          <router-link to="/main/transportadora/coletas/em-andamento">Coletas em Andamento</router-link>
          <a href="javascript:void(0)" @click="logout()">Logout</a>
        </div>
      </div>
      <div class="md-layout-item">
        <transition name="slide">
          <router-view></router-view>
        </transition>
      </div>
    </div>
  </div>
</template>

<script>
import { CHAVE_USUARIO_LOGIN } from "./contants";

export default {
  name: "transportadora-layout",
  methods: {
    logout() {
      localStorage.setItem(CHAVE_USUARIO_LOGIN, null);
      this.$router.push("/login");
    }
  },
  data() {
    return {
      usuario: null
    };
  },
  mounted() {
    this.usuario = this.getUsuario();
  }
};
</script>

<style scoped>
.transportadora-layout {
  margin-top: 90px;
}
.vertical-menu {
  width: 100%;
}

.vertical-menu a {
  background-color: #eeeeee;
  color: #000000;
  display: block;
  padding: 12px;
  text-decoration: none;
}

.vertical-menu a:hover {
  background-color: #cccccc;
  text-decoration: none;
}

.vertical-menu a.active {
  background-color: #4caf50;
  color: white;
}
</style>