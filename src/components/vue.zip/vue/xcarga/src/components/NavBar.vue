<template>
  <header>
    <img src="@/assets/logo.png" />
    <!-- <img src="https://codetheweb.blog/assets/img/icon2.png" /> -->
    <nav>
      <ul>
        <li>
          <router-link to="/main/home">Home</router-link>
        </li>
        <li v-if="usuario!==null && usuario.empresa.tipo===1">
          <router-link to="/main/ceramica">Ceramica</router-link>
        </li>
        <li v-if="usuario!==null && usuario.empresa.tipo===2">
          <router-link to="/main/transportadora">Transportadora</router-link>
        </li>
      </ul>
    </nav>
  </header>
</template>

<script>
export default {
  name: "nav-bar",
  data() {
    return {
      usuario: null
    };
  },
  mounted() {
    this.usuario = this.getUsuario();
  }
};
</script>

<style scoped>
header {
  background-color: white;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  height: 80px;
  display: flex;
  align-items: center;
  box-shadow: 0 0 25px 0 black;
  z-index: 5000;
}
header img {
  height: 50px;
  margin-left: 40px;
}
header * {
  display: inline;
}

header li {
  margin: 20px;
}

header li a,
.box-usuario a {
  color: black;
  text-decoration: none;
}

header div.box-usuario {
  height: 80px;
  display: block !important;
  position: absolute !important;
  right: 5px;
  padding-right: 10px;
}
header div.box-usuario * {
  display: block;
}
</style>