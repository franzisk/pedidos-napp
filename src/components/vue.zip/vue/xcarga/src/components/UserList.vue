<template>
  <div class="user-list">
    <div v-for="user in users" :key="user.id">
      <div>{{user.name}}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "user-list",
  data() {
    return {
      users: []
    };
  },
  methods: {
    fetchUsers: function() {
      const baseURI = "https://jsonplaceholder.typicode.com/users";
      this.$http.get(baseURI).then(result => {
        this.users = result.data;
      });
    }
  },
  mounted() {
    this.fetchUsers();
  }
};
</script>

<style scoped>
.user-list {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: left;
  width: 640px;
  margin: 0 auto;
  color: #0c3d6d;
  background-color: #a8a8a8;
}
</style>