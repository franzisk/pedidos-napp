<template>
  <div>
    <nav-bar :usuario="usuario" />

    <transition name="slide">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
import NavBar from "./NavBar";

//console.log("usuario = ", this.getUsuario());

export default {
  name: "authorized-layout",
  components: {
    NavBar
  },
  data() {
    return {
      usuario: null
    };
  },
  mounted() {
    this.usuario = this.getUsuario();
  }
};
</script>

<style scoped>
.authorized-layout {
  margin-top: 90px;
}
</style>