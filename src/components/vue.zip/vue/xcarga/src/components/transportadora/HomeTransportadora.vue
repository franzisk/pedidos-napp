<template>
  <div>Home Transportadora</div>
</template>

<script>
export default {
  name: "home-transportadora"
};
</script>

<style scoped>
</style>