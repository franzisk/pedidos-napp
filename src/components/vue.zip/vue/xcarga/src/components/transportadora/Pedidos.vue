<template>
  <div>
    <p v-if="pedidos.content.length < 1" class="empty-table">Nenhum produto encontrado</p>

    <md-table
      v-else
      v-model="pedidos.content"
      md-card
      md-sort="razaoSocialCliente"
      md-sort-order="asc"
    >
      <md-table-toolbar>
        <h1 class="md-title">Pedidos</h1>
      </md-table-toolbar>

      <md-table-row slot="md-table-row" slot-scope="{ item }">
        <md-table-cell md-label="ID" md-sort-by="id" md-numeric>{{ item.id }}</md-table-cell>
        <md-table-cell
          md-label="Cliente"
          md-sort-by="razaoSocialCliente"
        >{{ item.razaoSocialCliente }}</md-table-cell>
        <md-table-cell
          md-label="Local"
          md-sort-by="cidadeEnderecoCliente"
        >{{ item.cidadeEnderecoCliente }}</md-table-cell>
        <md-table-cell md-label="Produto" md-sort-by="produtoDocumento">{{ item.produtoDocumento }}</md-table-cell>

        <md-table-cell md-label="Disponível">
          {{item.quantidadeDisponivel - item.totalQuantidadeBaixa}}
          m
          <sup>2</sup>
        </md-table-cell>
        <md-table-cell md-label="Peso">{{item.pesoDisponivel}}</md-table-cell>
        <md-table-cell md-label="Paletes">{{item.paletesDisponiveis - item.totalPaletesBaixa}}</md-table-cell>
        <md-table-cell md-label="Caixas">{{item.caixasDisponiveis - item.totalCaixasBaixa}}</md-table-cell>
        <md-table-cell>
          <button v-bind:disabled="coleta===null" @click="adicionarItemNaColeta(item)">Adicionar</button>
        </md-table-cell>
      </md-table-row>
    </md-table>
  </div>
</template>

<script>
export default {
  name: "pedidos",
  data() {
    return {
      pedidos: {
        content: []
      },
      coleta: null
    };
  },
  methods: {
    adicionarItemNaColeta(item) {
      console.log(item);
    }
  },
  async mounted() {
    try {
      const usuario = this.getUsuario();
      const pagina = 1;
      const quantidade = 20;
      const url = `/api/carga/produto-transportadora/${pagina}/${quantidade}/itemDocumento,chaveDocumento`;
      const { data } = await this.$axios.get(url);
      this.pedidos = data;
      console.log(this.pedidos);
    } catch (error) {
      console.error(error);
    }
  }
};
</script>

<style scoped>
button[disabled] {
  background-color: #ebe9e6;
  border-color: #dbdbdb;
  color: #747474;
  opacity: 0.65;
  cursor: not-allowed;
}
</style>