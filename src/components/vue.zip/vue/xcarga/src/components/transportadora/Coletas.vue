<template>
  <div class="coletas">Coletas {{ tipo==='finalizadas' ? 'Finalizadas':'Em Andamento' }}</div>
</template>

<script>
export default {
  name: "coletas",
  data() {
    return {
      tipo: "",
      coletas: []
    };
  },
  methods: {
    async listarColetas() {
      console.log("listar coletas: ", this.tipo);
      const usuario = this.getUsuario();
      const pagina = 1;
      const quantidade = 5;
      try {
        const urlTipo =
          this.tipo === "finalizadas"
            ? "coletas-finalizadas"
            : "coletas-em-andamento";
        const url = `/api/transportadora/${urlTipo}/${pagina}/${quantidade}`;
        const { data } = await this.$axios.get(url);
        this.coletas = data;
      } catch (error) {
        console.error(error);
      }
    }
  },
  mounted() {
    this.tipo = this.$route.params.tipo;
    //console.log("-- mounted");
  },
  activated() {
    this.tipo = this.$route.params.tipo;
    //console.log("-- activated");
  },
  created() {
    //console.log("-- created");
  },
  beforeUpdate() {
    //console.log("-- beforeUpdate");
  },
  watch: {
    "$route.params.tipo": function(tipo) {
      this.tipo = tipo;
      console.log("tipo = ", this.tipo);
      this.listarColetas();
    }
  }
};
</script>

<style scoped>
.coletas {
  padding: 10px;
}
</style>