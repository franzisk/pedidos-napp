import Vue from "vue";
import App from "./App.vue";
import Main from "./Main.vue";
import VueRouter from "vue-router";
import axios from "axios";

import AuthorizedLayout from "./components/AuthorizedLayout.vue";
import Home from "./components/Home.vue";
import LoginForm from "./components/LoginForm.vue";
import TransportadoraLayout from "./components/TransportadoraLayout.vue";
import CeramicaLayout from "./components/CeramicaLayout.vue";
import Coletas from "./components/transportadora/Coletas.vue";
import HomeTransportadora from "./components/transportadora/HomeTransportadora.vue";
import Pedidos from "./components/transportadora/Pedidos.vue";

import { CHAVE_USUARIO_LOGIN, JWT_TOKEN } from "./components/contants";

import VueMaterial from "vue-material";
import "vue-material/dist/vue-material.min.css";
//import "vue-material/dist/theme/default-dark.css"; // This line here

Vue.use(VueMaterial);
const baseURL = "http://localhost:8088";

const routes = [
    { path: "/login", component: LoginForm, meta: { requiresAuth: false } },
    {
        path: "/main",
        component: AuthorizedLayout,
        meta: { requiresAuth: true },
        children: [
            { path: "home", component: Home, meta: { requiresAuth: true } },
            {
                path: "transportadora",
                component: TransportadoraLayout,
                meta: { requiresAuth: true },
                children: [
                    { path: "home", component: HomeTransportadora, meta: { requiresAuth: true } },
                    { path: "coletas/:tipo", component: Coletas, meta: { requiresAuth: true }, props: true },
                    { path: "pedidos", component: Pedidos, meta: { requiresAuth: true } }
                ]
            },
            { path: "ceramica", component: CeramicaLayout, meta: { requiresAuth: true } }
        ]
    }
];

const router = new VueRouter({
    mode: "history",
    base: __dirname,
    routes
});

// Check before each page load whether the page requires authentication/
// if it does check whether the user is signed into the web app or
// redirect to the sign-in page to enable them to sign-in
router.beforeEach((to, from, next) => {
    const currentUser =
        localStorage.getItem(CHAVE_USUARIO_LOGIN) === undefined ? null : JSON.parse(localStorage.getItem(CHAVE_USUARIO_LOGIN));
    const requiresAuth = to.matched.some(record => record.meta.requiresAuth);

    if (requiresAuth && !currentUser) {
        next("/login");
    } else if (requiresAuth && currentUser) {
        next();
    } else {
        next();
    }
});

Vue.prototype.getUsuario = () => {
    return localStorage.getItem(CHAVE_USUARIO_LOGIN) === undefined ? null : JSON.parse(localStorage.getItem(CHAVE_USUARIO_LOGIN));
};

export const getToken = () => localStorage.getItem(JWT_TOKEN) || "";

Vue.config.productionTip = false;

Vue.use(VueRouter);

Vue.prototype.$token = "";

export const api = axios.create({
    mode: "cors",
    baseURL: baseURL
});
api.interceptors.request.use(config => {
    const _token = getToken();
    if (_token) {
        config.headers.authorization = `Bearer ${_token}`;
    }
    return config;
});
Vue.prototype.$axios = api;

new Vue({
    router,
    render: h => h(Main)
}).$mount("#app");
