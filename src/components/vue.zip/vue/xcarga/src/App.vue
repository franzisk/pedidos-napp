<template>
  <div id="app" class="small-container">
    <!-- <img alt="Vue logo" src="./assets/logo.png" /> -->
    <!-- <Login mensagem="Mensagem passada no props" /> -->

    <!-- <employee-form @add:employee="addEmployee" />

    <employee-table
      @delete:employee="deleteEmployee"
      @edit:employee="editEmployee"
      :employees="employees"
    />-->

    <login-form />
  </div>
</template>

<script>
import LoginForm from "@/components/LoginForm";
//import EmployeeTable from "@/components/EmployeeTable";
//import EmployeeForm from "@/components/EmployeeForm";

export default {
  name: "app",
  components: {
    LoginForm
  },

  data() {
    return {
      employees: []
    };
  },

  mounted() {
    //this.getEmployees();
  },

  methods: {
    async getEmployees() {
      try {
        const url = "/users";
        const { data } = await this.$axios.get(url);
        this.employees = data;
      } catch (error) {
        console.error(error);
      }
    },

    async addEmployee(employee) {
      try {
        const response = await fetch(
          "https://jsonplaceholder.typicode.com/users",
          {
            method: "POST",
            body: JSON.stringify(employee),
            headers: { "Content-type": "application/json; charset=UTF-8" }
          }
        );
        const data = await response.json();
        this.employees = [...this.employees, data];
      } catch (error) {
        console.error(error);
      }
    },

    async editEmployee(id, updatedEmployee) {
      try {
        const response = await fetch(
          `https://jsonplaceholder.typicode.com/users/${id}`,
          {
            method: "PUT",
            body: JSON.stringify(updatedEmployee),
            headers: { "Content-type": "application/json; charset=UTF-8" }
          }
        );
        const data = await response.json();
        this.employees = this.employees.map(employee =>
          employee.id === id ? data : employee
        );
      } catch (error) {
        console.error(error);
      }
    },

    async deleteEmployee(id) {
      try {
        await fetch(`https://jsonplaceholder.typicode.com/users/${id}`, {
          method: "DELETE"
        });
        this.employees = this.employees.filter(employee => employee.id !== id);
      } catch (error) {
        console.error(error);
      }
    },

    __editEmployee(id, updatedEmployee) {
      this.employees = this.employees.map(employee =>
        employee.id === id ? updatedEmployee : employee
      );
    },
    __deleteEmployee(id) {
      this.employees = this.employees.filter(employee => employee.id !== id);
    },
    __addEmployee(employee) {
      // encontra o ultimo id usado
      const lastId =
        this.employees.length > 0
          ? this.employees[this.employees.length - 1].id
          : 0;
      // calcula o novo ID
      const id = lastId + 1;
      // adiciona a propriedade ID ao objeto
      const newEmployee = { ...employee, id };
      // atualiza a lista atual com o novo objeto
      this.employees = [...this.employees, newEmployee];
    }
  }
};
</script>

<style>
button {
  background: #009435;
  border: 1px solid #009435;
}

.small-container {
  max-width: 980px;
}
</style>
