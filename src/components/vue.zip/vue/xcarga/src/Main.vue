<template>
  <div id="app">
    <transition>
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
#app {
  margin: 0 auto;
  padding: 10px;
}
</style>